import React from "react";

const Statistics = () => {
  return (
    <div>
      <div>매장통계</div>
      <ul>
        <li>주문</li>
        <li>리뷰</li>
        <li>별점</li>
        <li>북마크</li>
        <li>매출</li>
      </ul>
      <div>
        <div>분석 데이터</div>
        <div>분석 데이터</div>
      </div>
      <div>분석 데이터</div>
    </div>
  );
};

export default Statistics;
