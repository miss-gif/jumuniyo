import React from "react";

const StoreManagement = () => {
  return (
    <di>
      <p>
        <div>현재 상태</div>
        <p>영업중</p>
      </p>
    </di>
  );
};

export default StoreManagement;
