import React from "react";

const CeoPage = () => {
  return <div>dd</div>;
};

export default CeoPage;
