import React from "react";
import Menu from "../components/restaurantdetail/Menu";

const RestaurantDetailPage = () => {
  return (
    <div>
      <Menu></Menu>
    </div>
  );
};

export default RestaurantDetailPage;
