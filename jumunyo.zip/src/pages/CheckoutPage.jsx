import React from "react";

const CheckoutPage = () => {
  return <div>CheckoutPage</div>;
};

export default CheckoutPage;
