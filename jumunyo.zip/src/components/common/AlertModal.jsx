import React from "react";

const AlertModal = () => {
  return <div>AlertModal</div>;
};

export default AlertModal;
