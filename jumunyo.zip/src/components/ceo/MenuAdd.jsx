import React from "react";

const MenuAdd = () => {
  return <div>MenuAdd</div>;
};

export default MenuAdd;
