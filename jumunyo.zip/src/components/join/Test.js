const Test = () => {
  return <div>Test</div>;
};

export default Test;
